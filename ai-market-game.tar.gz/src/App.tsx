import React, { useState, useEffect } from 'react';
import { MapComponent, FinancialChart } from './components';
import { useSocketConnection, useAIMessages, useAIThoughts, useFinancialUpdates, useGameState } from './hooks/useSocket';

function App() {
  const [currentTime, setCurrentTime] = useState(new Date());
  const { connectionStatus, isConnected } = useSocketConnection();
  const { messages } = useAIMessages();
  const { thoughts } = useAIThoughts();
  // Financial updates are now handled by FinancialChart component
  const { gameState, startSimulation, pauseSimulation, resetSimulation } = useGameState();

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-blue-900 relative overflow-hidden">
      {/* 背景网格线 */}
      <div className="absolute inset-0 bg-grid-cyan opacity-20"></div>
      <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
      
      {/* 动态背景光效 */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl animate-pulse"></div>
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
      <div className="absolute top-1/2 left-1/2 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl animate-pulse delay-2000 transform -translate-x-1/2 -translate-y-1/2"></div>
      
      {/* 顶部状态栏 */}
      <header className="relative z-10 border-b border-cyan-500/30 bg-black/20 backdrop-blur-md">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent">
                AI 模拟市场游戏系统
              </h1>
              <div className="text-xs text-cyan-300 opacity-70">
                NEURAL MARKET SIMULATION v2.1
              </div>
            </div>
            <div className="flex items-center space-x-6 text-sm">
              <div className="flex items-center space-x-2">
                <span className="text-cyan-400">◉</span>
                <span className="text-white">{currentTime.toLocaleTimeString()}</span>
              </div>
              <div className="flex items-center space-x-2">
                <span className={`${isConnected ? 'text-green-400' : 'text-red-400'}`}>
                  {isConnected ? '▲' : '▼'}
                </span>
                <span className={`${isConnected ? 'text-green-400' : 'text-red-400'}`}>
                  {connectionStatus.toUpperCase()}
                </span>
              </div>
              <div className="flex items-center space-x-2">
                <span className="text-blue-400">●</span>
                <span className="text-white">{gameState.activeAgents || 5} AI AGENTS</span>
              </div>
            </div>
          </div>
        </div>
      </header>
      
      <main className="relative z-10 container mx-auto px-6 py-8">
        {/* 核心监控面板 */}
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 mb-8">
          {/* 实时地图视图 */}
          <div className="xl:col-span-2 bg-black/30 backdrop-blur-md border border-cyan-500/30 rounded-xl p-6 shadow-2xl">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-white flex items-center">
                <span className="w-2 h-2 bg-cyan-400 rounded-full mr-3 animate-pulse"></span>
                实时地图视图
              </h2>
              <div className="flex space-x-2">
                <div className="w-3 h-3 bg-green-400 rounded-full animate-ping"></div>
                <div className="w-3 h-3 bg-yellow-400 rounded-full animate-ping delay-100"></div>
                <div className="w-3 h-3 bg-red-400 rounded-full animate-ping delay-200"></div>
              </div>
            </div>
            <MapComponent className="h-80" />
          </div>
          
          {/* AI状态面板 */}
          <div className="bg-black/30 backdrop-blur-md border border-cyan-500/30 rounded-xl p-6 shadow-2xl">
            <h2 className="text-lg font-semibold text-white mb-4 flex items-center">
              <span className="w-2 h-2 bg-green-400 rounded-full mr-3 animate-pulse"></span>
              AI 状态监控
            </h2>
            <div className="space-y-4">
              {['Alex Trader', 'Sam Business', 'Jordan Investor'].map((name, index) => (
                <div key={name} className="bg-gradient-to-r from-gray-800/50 to-gray-700/50 p-4 rounded-lg border border-cyan-500/20">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-white font-mono text-sm">{name}</span>
                    <div className="flex items-center space-x-2">
                      <div className={`w-2 h-2 rounded-full ${
                        index === 0 ? 'bg-green-400' : index === 1 ? 'bg-yellow-400' : 'bg-blue-400'
                      } animate-pulse`}></div>
                      <span className="text-xs text-gray-400">ACTIVE</span>
                    </div>
                  </div>
                  <div className="text-xs text-cyan-300 mb-2">Balance: ${(10000 + Math.random() * 5000).toFixed(0)}</div>
                  <div className="w-full bg-gray-700 rounded-full h-1">
                    <div className={`h-1 rounded-full ${
                      index === 0 ? 'bg-green-400' : index === 1 ? 'bg-yellow-400' : 'bg-blue-400'
                    }`} style={{width: `${60 + Math.random() * 40}%`}}></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
        
        {/* 数据监控区域 */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* 资金增长监控 */}
          <div className="bg-black/30 backdrop-blur-md border border-cyan-500/30 rounded-xl p-6 shadow-2xl">
            <h2 className="text-lg font-semibold text-white mb-4 flex items-center">
              <span className="w-2 h-2 bg-green-400 rounded-full mr-3 animate-pulse"></span>
              资金增长监控
            </h2>
            <FinancialChart className="h-64" />
          </div>
          
          {/* AI对话监控 */}
          <div className="bg-black/30 backdrop-blur-md border border-cyan-500/30 rounded-xl p-6 shadow-2xl">
            <h2 className="text-lg font-semibold text-white mb-4 flex items-center">
              <span className="w-2 h-2 bg-blue-400 rounded-full mr-3 animate-pulse"></span>
              AI 对话监控
            </h2>
            <div className="bg-gradient-to-br from-gray-900/50 to-blue-900/20 h-64 rounded-lg border border-blue-500/20 overflow-hidden">
              <div className="p-4 space-y-3 h-full overflow-y-auto custom-scrollbar">
                <div className="text-xs text-gray-400 mb-2">[NEURAL CHAT LOG] - {messages.length} messages</div>
                {messages.slice(-10).map((message, index) => (
                  <div key={message.id || index} className="bg-blue-500/10 p-2 rounded text-xs">
                    <span className="text-cyan-400">[{message.senderId}]:</span>
                    <span className="text-white ml-2">{message.message}</span>
                    {message.isLie && <span className="text-red-400 ml-2">🎭</span>}
                  </div>
                ))}
                {messages.length === 0 && (
                  <>
                    <div className="bg-blue-500/10 p-2 rounded text-xs">
                      <span className="text-cyan-400">[Alex]:</span>
                      <span className="text-white ml-2">Looking for investment opportunities...</span>
                    </div>
                    <div className="bg-green-500/10 p-2 rounded text-xs">
                      <span className="text-green-400">[Sam]:</span>
                      <span className="text-white ml-2">Starting new business venture in tech sector</span>
                    </div>
                    <div className="bg-purple-500/10 p-2 rounded text-xs">
                      <span className="text-purple-400">[Jordan]:</span>
                      <span className="text-white ml-2">Market analysis indicates bullish trend</span>
                    </div>
                  </>
                )}
                <div className="text-xs text-gray-500 animate-pulse flex items-center">
                  <div className={`w-2 h-2 rounded-full mr-2 animate-pulse ${
                    isConnected ? 'bg-green-400' : 'bg-red-400'
                  }`}></div>
                  {isConnected ? 'Live monitoring...' : 'Disconnected'}
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* AI思考监控和控制面板 */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* AI思考监控 */}
          <div className="bg-black/30 backdrop-blur-md border border-cyan-500/30 rounded-xl p-6 shadow-2xl">
            <h2 className="text-lg font-semibold text-white mb-4 flex items-center">
              <span className="w-2 h-2 bg-purple-400 rounded-full mr-3 animate-pulse"></span>
              AI 思考监控
            </h2>
            <div className="bg-gradient-to-br from-gray-900/50 to-purple-900/20 h-64 rounded-lg border border-purple-500/20 overflow-hidden">
              <div className="p-4 space-y-3 h-full overflow-y-auto custom-scrollbar">
                <div className="text-xs text-gray-400 mb-2">[NEURAL THOUGHT STREAM] - {thoughts.length} thoughts</div>
                {thoughts.slice(-5).map((thought, index) => (
                  <div key={thought.id || index} className="bg-purple-500/10 p-3 rounded border-l-2 border-purple-400 text-xs">
                    <div className="text-purple-400 font-mono mb-1">[{thought.agentName?.toUpperCase()}.exe]</div>
                    <div className="text-white">{thought.thought}</div>
                    <div className="text-gray-400 mt-1">
                      {thought.confidence && `Confidence: ${Math.round(thought.confidence)}%`}
                      {thought.decision && ` | Decision: ${thought.decision}`}
                    </div>
                  </div>
                ))}
                {thoughts.length === 0 && (
                  <>
                    <div className="bg-purple-500/10 p-3 rounded border-l-2 border-purple-400 text-xs">
                      <div className="text-purple-400 font-mono mb-1">[ALEX_TRADER.exe]</div>
                      <div className="text-white">Analyzing market volatility... Risk assessment: MEDIUM</div>
                      <div className="text-gray-400 mt-1">Confidence: 73% | Decision: INVEST</div>
                    </div>
                    <div className="bg-blue-500/10 p-3 rounded border-l-2 border-blue-400 text-xs">
                      <div className="text-blue-400 font-mono mb-1">[SAM_BUSINESS.exe]</div>
                      <div className="text-white">Evaluating startup opportunities in AI sector...</div>
                      <div className="text-gray-400 mt-1">Processing... Expected ROI: 145%</div>
                    </div>
                  </>
                )}
                <div className="text-xs text-gray-500 animate-pulse flex items-center">
                  <span className={`w-1 h-1 rounded-full mr-2 animate-ping ${
                    isConnected ? 'bg-purple-400' : 'bg-gray-400'
                  }`}></span>
                  {isConnected ? 'Neural processing active...' : 'Neural network offline'}
                </div>
              </div>
            </div>
          </div>
          
          {/* 控制面板 */}
          <div className="bg-black/30 backdrop-blur-md border border-cyan-500/30 rounded-xl p-6 shadow-2xl">
            <h2 className="text-lg font-semibold text-white mb-4 flex items-center">
              <span className="w-2 h-2 bg-red-400 rounded-full mr-3 animate-pulse"></span>
              系统控制面板
            </h2>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <button 
                  onClick={gameState.isRunning ? pauseSimulation : startSimulation}
                  disabled={!isConnected}
                  className={`bg-gradient-to-r ${
                    gameState.isRunning 
                      ? 'from-red-600/20 to-red-400/20 hover:from-red-600/40 hover:to-red-400/40 border-red-500/50 text-red-400 hover:shadow-red-400/20'
                      : 'from-green-600/20 to-green-400/20 hover:from-green-600/40 hover:to-green-400/40 border-green-500/50 text-green-400 hover:shadow-green-400/20'
                  } border px-4 py-3 rounded-lg font-mono text-sm transition-all duration-300 hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed`}
                >
                  {gameState.isRunning ? '⏸ PAUSE SYSTEM' : '► START SIMULATION'}
                </button>
                <button 
                  onClick={resetSimulation}
                  disabled={!isConnected}
                  className="bg-gradient-to-r from-yellow-600/20 to-yellow-400/20 hover:from-yellow-600/40 hover:to-yellow-400/40 border border-yellow-500/50 text-yellow-400 px-4 py-3 rounded-lg font-mono text-sm transition-all duration-300 hover:shadow-lg hover:shadow-yellow-400/20 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  🔄 RESET DATA
                </button>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <button 
                  disabled={!isConnected}
                  className="bg-gradient-to-r from-blue-600/20 to-blue-400/20 hover:from-blue-600/40 hover:to-blue-400/40 border border-blue-500/50 text-blue-400 px-4 py-3 rounded-lg font-mono text-sm transition-all duration-300 hover:shadow-lg hover:shadow-blue-400/20 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  📊 VIEW ANALYTICS
                </button>
                <button 
                  disabled={!isConnected}
                  className="bg-gradient-to-r from-purple-600/20 to-purple-400/20 hover:from-purple-600/40 hover:to-purple-400/40 border border-purple-500/50 text-purple-400 px-4 py-3 rounded-lg font-mono text-sm transition-all duration-300 hover:shadow-lg hover:shadow-purple-400/20 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  ⚙ NEURAL CONFIG
                </button>
              </div>
              
              {/* 系统状态指示器 */}
              <div className="mt-6 p-4 bg-gray-900/50 rounded-lg border border-cyan-500/20">
                <div className="text-xs text-gray-400 mb-3">SYSTEM STATUS</div>
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-xs text-white">Neural Network</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                      <span className="text-xs text-green-400">ONLINE</span>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-xs text-white">Market Engine</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                      <span className="text-xs text-green-400">ACTIVE</span>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-xs text-white">AI Agents</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-yellow-400 rounded-full animate-pulse"></div>
                      <span className="text-xs text-yellow-400">LEARNING</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;

import express from 'express';
import { createServer } from 'http';
import { Server as SocketIOServer } from 'socket.io';
import mongoose from 'mongoose';
import cors from 'cors';
import dotenv from 'dotenv';

// Import models
import { AIEntity, Transaction, GameSession, ChatLog, ThoughtProcess } from './models';

// Import AI system (temporarily disabled)
// import { AIManager } from './ai/AIManager';

// Load environment variables
dotenv.config();

const app = express();
const httpServer = createServer(app);

// Configure Socket.IO with CORS
const io = new SocketIOServer(httpServer, {
  cors: {
    origin: ['http://localhost:3000', '*.clackypaas.com'],
    methods: ['GET', 'POST'],
    credentials: true
  }
});

// Middleware
app.use(cors({
  origin: ['http://localhost:3000', '*.clackypaas.com'],
  credentials: true
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// MongoDB connection
const MONGO_URI = process.env.MONGO_URI || 'mongodb://admin:zVSeOEHa@127.0.0.1:27017/admin';

// Global AI Manager instance (temporarily disabled)
// let aiManager: AIManager | null = null;

mongoose.connect(MONGO_URI)
  .then(async () => {
    console.log('✅ Connected to MongoDB');
    
    // Initialize or get the default game session
    // await initializeGameSession(); // Temporarily disabled
  })
  .catch((error) => {
    console.error('❌ MongoDB connection error:', error);
  });

// Basic health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'OK', 
    message: 'AI Market Game Server is running',
    timestamp: new Date().toISOString(),
    database: mongoose.connection.readyState === 1 ? 'Connected' : 'Disconnected'
  });
});

// API endpoints for AI management (temporarily disabled)
/*
app.post('/api/ai/spawn', async (req, res) => {
  // AI spawning endpoint - will be implemented later
  res.json({ message: 'AI system under development' });
});
*/

// Initialize game session and AI manager (temporarily disabled)
/*
async function initializeGameSession() {
  // Game session initialization - will be implemented later
}
*/

// Test database collections endpoint
app.get('/api/db-test', async (req, res) => {
  try {
    if (!mongoose.connection.db) {
      return res.status(500).json({
        status: 'Error',
        message: 'Database not connected'
      });
    }
    
    const collections = await mongoose.connection.db.listCollections().toArray();
    const stats = {
      aiEntities: await AIEntity.countDocuments(),
      transactions: await Transaction.countDocuments(),
      gameSessions: await GameSession.countDocuments(),
      chatLogs: await ChatLog.countDocuments(),
      thoughtProcesses: await ThoughtProcess.countDocuments()
    };
    
    res.json({
      status: 'OK',
      collections: collections.map(col => col.name),
      documentCounts: stats,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    res.status(500).json({
      status: 'Error',
      message: 'Database test failed',
      error: error instanceof Error ? error.message : 'Unknown error'
    });
  }
});

// Socket.IO connection handling
io.on('connection', (socket) => {
  console.log(`✅ Client connected: ${socket.id}`);
  
  // AI interaction events
  socket.on('ai-message', (data) => {
    console.log('AI Message:', data);
    // Broadcast to all connected clients
    io.emit('ai-message-broadcast', data);
  });
  
  // AI thought process events
  socket.on('ai-thought', (data) => {
    console.log('AI Thought:', data);
    io.emit('ai-thought-broadcast', data);
  });
  
  // Game state events
  socket.on('game-state-update', (data) => {
    console.log('Game State Update:', data);
    io.emit('game-state-broadcast', data);
  });
  
  // AI position updates
  socket.on('ai-position-update', (data) => {
    console.log('AI Position Update:', data);
    io.emit('ai-position-broadcast', data);
  });
  
  // Financial data updates
  socket.on('financial-update', (data) => {
    console.log('Financial Update:', data);
    io.emit('financial-broadcast', data);
  });
  
  socket.on('disconnect', (reason) => {
    console.log(`❌ Client disconnected: ${socket.id}, reason: ${reason}`);
  });
});

const PORT = process.env.PORT || 3002;

httpServer.listen(PORT, () => {
  console.log(`🚀 AI Market Game Server running on port ${PORT}`);
  console.log(`📡 Socket.IO server ready`);
  console.log(`🌐 Server accessible at http://localhost:${PORT}`);
  console.log(`🎮 Game system ready`);
  console.log(`🤖 AI system integrated`);
});